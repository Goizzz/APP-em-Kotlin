package com.example.projectpet.view

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.GridLayout
import androidx.recyclerview.widget.GridLayoutManager
import com.example.projectpet.R
import com.example.projectpet.adapter.ServicosAdapter
import com.example.projectpet.databinding.ActivityHomeBinding
import com.example.projectpet.model.Servicos

class Home : AppCompatActivity() {

    private lateinit var binding : ActivityHomeBinding
    private lateinit var servicosAdapter : ServicosAdapter
    private val ListaServicos : MutableList<Servicos> = mutableListOf()



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()
        val nome = intent.extras?.getString("nome")
        binding.txtnome.text = "Bem vindo(a),$nome"

        val recyclerViewServicos = binding.recycleViewServicos
        recyclerViewServicos.layoutManager = GridLayoutManager(this,2)
        servicosAdapter = ServicosAdapter(this,ListaServicos)
        recyclerViewServicos.setHasFixedSize(true)
        recyclerViewServicos.adapter = servicosAdapter
        getServicos()
        binding.btAgendar.setOnClickListener{
            val intent = Intent(this,Agendamento::class.java)
            intent.putExtra("nome",nome)
            startActivity(intent)
        }

    }

    private fun getServicos(){
        val servico1 = Servicos(R.drawable.shampoo, nome = "Banho")
        ListaServicos.add(servico1)

        val servico2 = Servicos(R.drawable.racao, nome = "Retirada de ração")
        ListaServicos.add(servico2)

        val servico3 = Servicos(R.drawable.veterinario, nome = "Consulta veterinária")
        ListaServicos.add(servico3)

        val servico4 = Servicos(R.drawable.coracao, nome = "Adoção")
        ListaServicos.add(servico4)
    }
}