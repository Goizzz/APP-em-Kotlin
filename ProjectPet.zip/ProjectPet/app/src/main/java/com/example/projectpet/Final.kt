package com.example.projectpet

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.projectpet.databinding.ActivityFinalBinding

class Final : AppCompatActivity() {

    private lateinit var binding : ActivityFinalBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_final)

        binding = ActivityFinalBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.hide()

        val telefone = intent.extras?.getString("telefone")
        val nome = intent.extras?.getString("nome")

        binding.txtagra.text = "Muito obrigado pela preferencia senhor(a),$nome, 5 minutos antes da sua consulta iremos enviar um SMS para verificação no seguinte telefone:  $telefone"
    }
}