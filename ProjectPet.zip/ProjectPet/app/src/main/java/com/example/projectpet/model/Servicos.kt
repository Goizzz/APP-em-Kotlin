package com.example.projectpet.model

data class Servicos (
    val img : Int? = null,
    val nome : String? = null,
)
