package com.example.projectpet.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.projectpet.databinding.ServicosItemBinding
import com.example.projectpet.model.Servicos

class ServicosAdapter(private val context : Context, private val listasServicos:MutableList<Servicos> ) :
    RecyclerView.Adapter<ServicosAdapter.ServicosViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ServicosViewHolder {
        val itemLista = ServicosItemBinding.inflate(LayoutInflater.from(context),parent,false)
        return ServicosViewHolder(itemLista)
    }

    override fun getItemCount() = listasServicos.size


    override fun onBindViewHolder(holder: ServicosViewHolder, position: Int) {
        holder.imgServicos.setImageResource(listasServicos[position].img!!)
        holder.txtServicos.text=listasServicos[position].nome
    }

    inner class ServicosViewHolder(binding:ServicosItemBinding): RecyclerView.ViewHolder(binding.root){
        val imgServicos = binding.imgServico
        val txtServicos = binding.txtServico
    }

}